/*
 * Licensed to Elasticsearch under one or more contributor
 * license agreements. See the NOTICE file distributed with
 * this work for additional information regarding copyright
 * ownership. Elasticsearch licenses this file to you under
 * the Apache License, Version 2.0 (the "License"); you may
 * not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

package com.infinilabs.stconvert.opensearch;

import com.infinilabs.stconvert.core.STConvertCharFilter;
import com.infinilabs.stconvert.core.STConvertType;
import org.opensearch.common.settings.Settings;
import org.opensearch.env.Environment;
import org.opensearch.index.IndexSettings;
import org.opensearch.index.analysis.AbstractCharFilterFactory;
import org.opensearch.index.analysis.NormalizingCharFilterFactory;

import java.io.Reader;

public class STConvertCharFilterFactory extends AbstractCharFilterFactory implements NormalizingCharFilterFactory {

    STConvertType convertType = STConvertType.SIMPLE_2_TRADITIONAL;

    public STConvertCharFilterFactory(IndexSettings indexSettings, Environment env, String name, Settings settings) {
        super(indexSettings, name);

        String type = settings.get("convert_type", "s2t");

        if (type.equals("t2s")) {
            convertType = STConvertType.TRADITIONAL_2_SIMPLE;
        }
    }


    @Override
    public Reader create(Reader tokenStream) {

        return new STConvertCharFilter(tokenStream, convertType);
    }
}
